
document.addEventListener("DOMContentLoaded", function (e) {
   document.body.className = '';
});